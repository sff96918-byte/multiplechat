# ChitChat capture report

Session: `session_20261011_012346`

## Event counts

- ws: 194
- http: 124
- third_party: 56
- ui: 37
- dom_messages: 35
- screenshot: 31
- ws_open: 4
- ws_close: 2
- session_start: 1
- session_end: 1

## Selector health (bot যে selector ব্যবহার করে)

| selector | hit rate | last count | status |
|---|---|---|---|
| main_ol | 0.582 | 1 | OK |
| msg_li_select_text | 0.537 | 9 | OK |
| username_span | 0.0 | 0 | NOT FOUND |
| msg_span_emoji | 0.537 | 9 | OK |
| textarea_name_message | 0.582 | 1 | OK |
| textarea_placeholder_message | 0.582 | 1 | OK |
| input_text | 0.006 | 0 | OK |
| textarea_any | 0.781 | 2 | OK |
| sidebar_truncate_user | 0.0 | 0 | NOT FOUND |
| sidebar_bg_panel_user | 0.0 | 0 | NOT FOUND |

## HTTP endpoints

| request | count | statuses |
|---|---|---|
| `GET /api/frontend` | 26 | {'200': 4, '304': 22} |
| `POST /users/me/conversations/{id}/typing` | 16 | {'201': 16} |
| `PATCH /users/me/conversations/{id}/read` | 15 | {'200': 15} |
| `POST /users/me/conversations/{id}/messages` | 15 | {'201': 15} |
| `GET /` | 12 | {'200': 12} |
| `POST /api/frontend/client/metrics` | 5 | {'200': 5} |
| `POST /cdn-cgi/rum` | 4 | {'204': 4} |
| `POST /match` | 4 | {'403': 1, '201': 3} |
| `GET /match/active` | 3 | {'200': 3} |
| `GET /users/me/conversations/{id}/messages` | 3 | {'200': 3} |
| `GET /users/me` | 2 | {'200': 2} |
| `GET /users/me/notifications` | 2 | {'200': 2} |
| `GET /users/me/relationships` | 2 | {'200': 2} |
| `GET /users/me/conversations/dm` | 2 | {'200': 2} |
| `GET /moderation/ban` | 2 | {'404': 2} |
| `GET /moderation/standing` | 2 | {'200': 2} |
| `GET /auth/session-status` | 1 | {'200': 1} |
| `POST /auth/signup` | 1 | {'201': 1} |
| `POST /auth/claim-account` | 1 | {'403': 1} |
| `GET /users/me/limits` | 1 | {'200': 1} |
| `POST /auth/logout` | 1 | {'201': 1} |
| `POST /auth/login` | 1 | {'201': 1} |
| `GET /_app/sounds/matched.mp3` | 1 | {'200': 1} |
| `GET /_app/sounds/message.mp3` | 1 | {'200': 1} |
| `PATCH /match/disconnect` | 1 | {'200': 1} |

## WebSocket events

- `in:chatMessage`: 60
- `in:typing`: 32
- `in:raw:in`: 26
- `in:onlineFriends`: 22
- `out:raw:out`: 20
- `out:presenceSync`: 18
- `in:matchUpdate`: 12
- `in:messageEdited`: 4

## Partner message -> our send delay (ms)

[2817, 2817, 5979, 5979, 3250, 3250, 1942, 1941, 7209, 7209, 5825, 5824, 4392, 4392, 14, 13, 24, 23, 11300, 11299, 6450, 6450, 14, 13, 11565, 11564, 14, 14, 12, 11]

## UI action -> next HTTP

- t=6.1 {'type': 'click', 'tag': 'button', 'text': '<text len=19>', 'aria': None, 't': 1791660232194} -> []
- t=8.21 {'type': 'click', 'tag': 'button', 'text': '<text len=19>', 'aria': None, 't': 1791660233425} -> []
- t=10.33 {'type': 'click', 'tag': 'button', 'text': '<text len=17>', 'aria': None, 't': 1791660235913} -> []
- t=37.9 {'type': 'click', 'tag': 'button', 'text': '<text len=19>', 'aria': None, 't': 1791660263610} -> ['POST /match [403]']
- t=41.07 {'type': 'click', 'tag': 'button', 'text': '<text len=5>', 'aria': None, 't': 1791660266513} -> []
- t=42.13 {'type': 'click', 'tag': 'button', 'text': '<text len=12>', 'aria': None, 't': 1791660267474} -> []
- t=43.2 {'type': 'click', 'tag': 'button', 'text': '<text len=19>', 'aria': None, 't': 1791660268793} -> []
- t=75.36 {'type': 'click', 'tag': 'button', 'text': '<text len=0>', 'aria': 'Show password', 't': 1791660301224} -> ['POST /auth/claim-account [403]', 'GET /api/frontend [304]']
- t=76.43 {'type': 'click', 'tag': 'button', 'text': '<text len=4>', 'aria': None, 't': 1791660302233} -> ['POST /auth/claim-account [403]', 'GET /api/frontend [304]']
- t=79.63 {'type': 'click', 'tag': 'button', 'text': '<text len=5>', 'aria': None, 't': 1791660304962} -> ['GET /users/me/limits [200]']
- t=80.71 {'type': 'click', 'tag': 'button', 'text': '<text len=0>', 'aria': 'Settings', 't': 1791660306297} -> ['GET /users/me/limits [200]']
- t=81.78 {'type': 'click', 'tag': 'button', 'text': '<text len=0>', 'aria': 'Settings', 't': 1791660307713} -> ['POST /auth/logout [201]', 'POST /cdn-cgi/rum [204]', 'GET /api/frontend [200]']
- t=82.83 {'type': 'click', 'tag': 'button', 'text': '<text len=7>', 'aria': None, 't': 1791660308609} -> ['POST /auth/logout [201]', 'POST /cdn-cgi/rum [204]', 'GET /api/frontend [200]']
- t=84.97 {'type': 'click', 'tag': 'button', 'text': '<text len=14>', 'aria': None, 't': 1791660310474} -> ['POST /auth/logout [201]', 'POST /cdn-cgi/rum [204]', 'GET /api/frontend [200]']
- t=87.08 {'type': 'click', 'tag': 'button', 'text': '<text len=19>', 'aria': None, 't': 1791660312673} -> []
- t=138.54 {'type': 'click', 'tag': 'button', 'text': '<text len=6>', 'aria': None, 't': 1791660364409} -> ['GET /api/frontend [304]', 'POST /auth/login [201]', 'GET /users/me [200]']
- t=141.8 {'type': 'click', 'tag': 'button', 'text': '<text len=19>', 'aria': None, 't': 1791660367377} -> ['GET /match/active [200]', 'GET /users/me/conversations/{id}/messages [200]']
- t=146.17 {'type': 'click', 'tag': 'button', 'text': '<text len=21>', 'aria': 'START', 't': 1791660371850} -> ['GET /users/me/conversations/{id}/messages [200]', 'PATCH /users/me/conversations/{id}/read [200]']
- t=151.62 {'type': 'enter', 'target_tag': 'textarea', 'target_name': 'message', 'value_len': 2, 't': 1791660377257} -> ['POST /users/me/conversations/{id}/messages [201]', 'GET / [200]', 'GET /api/frontend [304]']
- t=158.2 {'type': 'enter', 'target_tag': 'textarea', 'target_name': 'message', 'value_len': 4, 't': 1791660383817} -> ['POST /users/me/conversations/{id}/typing [201]', 'POST /users/me/conversations/{id}/messages [201]', 'PATCH /users/me/conversations/{id}/read [200]']
- t=160.43 {'type': 'enter', 'target_tag': 'textarea', 'target_name': 'message', 'value_len': 2, 't': 1791660385777} -> ['PATCH /users/me/conversations/{id}/read [200]', 'PATCH /users/me/conversations/{id}/read [200]']
- t=167.02 {'type': 'enter', 'target_tag': 'textarea', 'target_name': 'message', 'value_len': 2, 't': 1791660393049} -> ['POST /users/me/conversations/{id}/messages [201]', 'POST /users/me/conversations/{id}/typing [201]', 'GET /api/frontend [304]']
- t=170.4 {'type': 'enter', 'target_tag': 'textarea', 'target_name': 'message', 'value_len': 6, 't': 1791660395920} -> []
- t=185.43 {'type': 'enter', 'target_tag': 'textarea', 'target_name': 'message', 'value_len': 4, 't': 1791660411617} -> ['POST /users/me/conversations/{id}/messages [201]']
- t=201.6 {'type': 'enter', 'target_tag': 'div', 'target_name': None, 'value_len': 426, 't': 1791660427377} -> []
- t=206.95 {'type': 'enter', 'target_tag': 'textarea', 'target_name': 'message', 'value_len': 5, 't': 1791660432817} -> ['POST /users/me/conversations/{id}/messages [201]', 'POST /users/me/conversations/{id}/typing [201]', 'POST /users/me/conversations/{id}/messages [201]']
- t=209.14 {'type': 'enter', 'target_tag': 'textarea', 'target_name': 'message', 'value_len': 4, 't': 1791660435185} -> ['POST /users/me/conversations/{id}/messages [201]']
- t=219.94 {'type': 'enter', 'target_tag': 'textarea', 'target_name': 'message', 'value_len': 7, 't': 1791660445809} -> ['POST /users/me/conversations/{id}/messages [201]']
- t=254.31 {'type': 'enter', 'target_tag': 'textarea', 'target_name': 'message', 'value_len': 50, 't': 1791660479833} -> []
- t=281.18 {'type': 'click', 'tag': 'button', 'text': '<text len=21>', 'aria': 'SKIP', 't': 1791660507345} -> ['PATCH /match/disconnect [200]', 'POST /match [201]', 'GET /users/me/conversations/{id}/messages [200]']

> এই রিপোর্টে message text ও username masked। পূর্ণ data শুধু local events.jsonl-এ।
