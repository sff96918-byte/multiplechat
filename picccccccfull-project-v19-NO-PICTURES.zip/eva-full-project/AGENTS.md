# AGENTS.md — EVA Bot (root project) — প্রতিটা agent এটা আগে পড়বে

এই ফাইল হলো এই প্রজেক্টের **মূল গাইড**। নতুন agent বা নতুন session শুরু হলে
এখান থেকে শুরু করবে। ইউজার বাংলায় কথা বলেন — উত্তর বাংলায় দেবে (টেকনিক্যাল
শব্দ ইংরেজিতে থাকতে পারে)। ইউজার অপ্রয়োজনীয় কথা, বানানো setup, বা কাজ না-করা
জিনিস পছন্দ করেন না — তাই ছোট, সরাসরি, যাচাই-করা পরিবর্তন দাও।

---

## 1. ৩০ সেকেন্ডে প্রজেক্ট

EVA Bot একটি Python (PyQt6 GUI) অ্যাপ। chitchat.gg-তে random stranger-দের সাথে
**auto match → chat → reply → skip → next** করে। দুই ভাবে চলে:

| Mood | কীভাবে | কোড |
|---|---|---|
| 🌐 **LIVE BROWSER** | Camoufox browser automation (login, UI chat) | `browser/browser_automation.py` |
| ⚡ **SESSION CHAT** | Browser ছাড়া — account session/token দিয়ে সরাসরি WebSocket chat | `core/session_chat.py` + `core/ws_transport/` |

দুই mood-ই **একই reply engine** (`chat/rule_bot.py` → `ChatRuleBot`, ভিতরে
`eva_flow.py` funnel) এবং **একই timing config** (`data/config.json`) ব্যবহার করে।
Reply content আসে `data/input/` (ইউজার কী লিখল → trigger) আর `data/output/`
(bot কী লিখবে → reply লাইন) এর `.txt` ফাইল থেকে।

---

## 2. ফোল্ডার ম্যাপ

```
run.vbs / run_console.bat  → GUI / console launcher
entry/main.py              → PyQt6 GUI (sidebar pages: Dashboard, Live Chat, Sessions,
                             Accounts, Settings) — ~2600 লাইন।
                             Logs একটাই জায়গায়: Dashboard-এর ভিতরে "LIVE LOG" panel
                             (`_build_logs_panel`) — search/clear/export/thread tabs
entry/thread_manager.py    → browser mode-এর worker orchestration (QThread + signals)
entry/cli_runner.py        → CLI runner
entry/paths.py             → project_root(), data_dir()  ← সব path এখান থেকে
core/session_chat.py       → SESSION CHAT: source discovery, token resolve,
                             _ChatRuleEngine, SessionChatWorker(QThread)
core/ws_transport/         → chitchat.gg WebSocket protocol (socket.io codec, REST,
                             chat loop) — protocol_manifest.json = source of truth
core/config_loader.py      → config.json loader: load_chat_timing(), load_runtime_config(),
                             load_human_behavior()
core/engine_bridge.py      → engine ↔ worker bridge
core/account_manager.py    → account list / session store helpers
core/resource_governor.py  → CPU/RAM cap, worker throttling
core/signin_window.py      → login window
browser/                   → Camoufox automation, human_behavior, context_pool,
                             account_session_store, device_signin
chat/rule_bot.py           → ChatRuleBot (public reply API) — EVA_ENGINE env (default flow)
chat/rules.py              → RuleEngine + InputOutputEngine (txt matcher), chat_debug.log
chat/common_scan.py        → gender/age/country detection
chat/content_filter.py     → content filter
chat/database/loader.py    → DB loader (EVA_BOT_DB_ROOT env)
eva_flow.py                → funnel state machine (EvaFlowBot)  ← মূল flow logic
data/config.json           → SETTINGS (timing, human_behavior, thread, engine)
data/input/*.txt           → trigger keywords (ইউজার কী বলল)
data/output/*.txt          → reply lines (bot কী বলবে)  + output/middle_chat/
data/snap_ids.txt          → snapchat ID pool
data/logs/                 → chat_debug.log, gui_console.log, runtime logs
account_sessions/<key>/    → storage_state.json (TOKEN!), metadata.json, fingerprint.json
configs/session.json       → (optional) manual session/token source — SECRET
test_*.py, demo_*.py       → test/demo scripts (সব চলে, নিচে §5)
tools/live_chat.py         → interactive REPL: নিজে stranger হয়ে bot-এর reply দেখো
docs/                      → Architecture.txt, FLOW_SPEC.md, TASKS.md, PROJECT_STATE.md
skills/                    → task-ভিত্তিক playbook (নিচে §3)
```

**নিয়ম:** data-র path কখনো hard-code করবে না — `entry/paths.py`-র `data_dir()`
বা `project_root()` ব্যবহার করো।

---

## 3. SKILLS — কোন কাজে কোন skill পড়বে

| কাজ | পড়ো |
|---|---|
| প্রজেক্ট বুঝতে চাও / কোথায় কী আছে | `skills/project-map/SKILL.md` |
| ⚡ SESSION CHAT চালু হচ্ছে না / live chat বন্ধ / token সমস্যা | `skills/session-chat-debug/SKILL.md` |
| যেকোনো error / traceback / EXE-এর DLL error / crash | `skills/fix-error/SKILL.md` |
| bot-এর reply বদলাতে / নতুন line যোগ করতে / funnel বুঝতে | `skills/reply-content/SKILL.md` |
| GUI page / button / Qt signal যোগ বা বদল | `skills/gui-dashboard/SKILL.md` |
| chitchat.gg WebSocket protocol বদলাতে হলে | `skills/chitchat-protocol/SKILL.md` |
| কাজ শেষে যাচাই (কোন test কখন চালাবে) | `skills/verify/SKILL.md` |

একই সময়ে একাধিক skill লাগতে পারে। সবসময় **verify** skill-এর gate দিয়ে শেষ করো।

---

## 4. কাজের নিয়ম (HARD RULES)

1. **Read first.** কোড বদলানোর আগে সংশ্লিষ্ট ফাইল ও function পড়ো। অনুমান
   করে edit করবে না। Finding-কে **CONFIRMED** (কোড/log থেকে প্রমাণিত),
   **LIKELY** (প্রমাণ আংশিক), **UNKNOWN** (জানা নেই) — এভাবে আলাদা করে বলো।
2. **Minimal change.** শুধু দরকারি জিনিস বদলাও। working architecture, public API,
   বা অন্য feature ভাঙবে না। unrelated file reformat করবে না।
3. **No new setup/launcher.** ইউজার আলাদা `.bat`/session-mode/setup চান না।
   নতুন feature সবসময় এই project-এর ভিতরে যাবে (GUI page বা existing engine)।
4. **Graceful fallback.** optional subsystem (Camoufox, ContextPool, PyQt বা
   aiohttp না থাকলে) ভাঙলে যেন পুরো app না পড়ে — error message দেখিয়ে degrade করো।
5. **Secrets কখনো log/zip/git-এ নয়।** `account_sessions/`, `storage_state.json`,
   `configs/session.json`, cookie, JWT, proxy credential — এগুলো কখনো print,
   log, বা zip-এ দেবে না। Debug output-এ শুধু boolean/নাম দেখাও (যেমন `has_token: true`).
6. **Protocol guess নিষেধ।** chitchat.gg wire protocol-এর প্রতিটা behavior
   `core/ws_transport/protocol_manifest.json`-এর capture evidence থেকে আসবে।
   না জানলে ইউজারের কাছে নতুন capture চাও।
7. **Bounded everything.** network-এ timeout, retry-এ backoff (অসীম loop নয়),
   log file rotate, queue bound।
8. **Verify না করে "done" বলবে না।** §5 এর gate পাস না হলে কাজ শেষ নয়। যা চালাওনি
   তা "পাস" বলবে না। Static check আর runtime check আলাদা করে লেখো।
9. **Windows-aware.** ইউজার Windows-এ `C:\Users\...\Downloads\...` থেকে চালায়।
   path-এ `os.path`/`pathlib` ব্যবহার করো; `\` hard-code করবে না; console encoding
   UTF-8 (`PYTHONIOENCODING=utf-8`) মাথায় রাখো। `pythonw` (windowless) এ `sys.stdout`
   `None` হতে পারে — `print` করার আগে check করো।
10. **Sandbox-এ chitchat.gg network নেই।** live chat test ইউজারের PC-তে হয়। Sandbox-এ
    শুধু offline/mock/unit test দিয়ে যাচাই হবে — এবং সেটা স্পষ্ট করে বলবে।

---

## 5. VERIFY GATE (কাজ শেষে বাধ্যতামূলক)

Root project-এ (এই folder থেকে):

```bash
python -m py_compile entry/main.py entry/thread_manager.py entry/paths.py \
    browser/browser_automation.py core/config_loader.py core/session_chat.py \
    core/ws_transport/ws_chat_loop.py
python -c "import chat; import eva_flow; print('import ok')"
python test_matcher.py      # input → output pool round-trip
python test_live.py         # funnel state machine (44 checks)
python test_fuzz.py         # random input, state valid (4 checks)
python test_flow.py         # flow ও branch (124 checks)
python demo_chat.py         # scripted stranger → END
```
Windows-এ একসাথে: `test.bat` (matcher + live + fuzz + demo)।

Session chat বদলালে অতিরিক্ত:
```bash
QT_QPA_PLATFORM=offscreen python -m core.session_chat --list   # source discovery
QT_QPA_PLATFORM=offscreen python -m core.session_chat --help   # CLI ঠিক আছে কি
```
(network ছাড়া live connect ব্যর্থ হওয়া স্বাভাবিক — কিন্তু error পরিষ্কার হতে হবে, crash নয়।)

GUI বদলালে: `QT_QPA_PLATFORM=offscreen python -c "import entry.main"` (import-level check)।

**Result রিপোর্টে লেখো:** কোন command চালানো হয়েছে, pass/fail সংখ্যা, এবং কী চালানো যায়নি (যেমন live chat)।

---

## 6. ডেলিভারি / ZIP

- zip-এ **থাকবে:** সব source, `data/` (config/txt), `docs/`, `skills/`, `AGENTS.md`, `README.md`।
- zip-এ **থাকবে না:** `account_sessions/` (login token), `configs/session.json`,
  `data/logs/`, `__pycache__/`, `*.pyc`, `build/`, `dist/`, `.venv/`, পুরনো `*.zip`।
- zip বানানোর পর খুলে যাচাই করো: secret নেই, key file আছে, ফাইল সংখ্যা ও byte size লেখো।
- ইউজারকে দেবে: zip ফাইলের নাম, byte size, এবং download link।

---

## 7. ইউজারের সমস্যা এলে

1. আগে `skills/fix-error/SKILL.md` অনুযায়ী log চাও (`data/logs/`, Dashboard-এর LIVE LOG panel,
   বা `[session]` লাইন)।
2. সমস্যা কোন mood-এ — LIVE BROWSER নাকি SESSION CHAT — আগে নির্ধারণ করো।
3. Root cause বাংলায় ব্যাখ্যা করো → minimal fix → verify gate → zip + link।

---

## 8. বর্তমান অবস্থা (snapshot)

- **Skip নিয়ম (v17):** Max Replies cap নেই — snap share পর্যন্ত chat চলে; partner চুপ থাকলে Settings-এর "Silence timeout" (default 90s) পর্যন্ত অপেক্ষা, তারপর পরের user। Engine END (snap ছাড়া, যেমন underage) হলে farewell একবার যায়, তারপর আর reply নেই → পরের user (v18, `farewell_sent`)। New Chat Delay শুধু chat-এর মাঝে wait (Settings থেকে)। Dashboard-এ timing override নেই।
- **Session chat:** ইন্টিগ্রেটেড (SESSIONS page-এ ⚡ box)। Sandbox-এ engine ও
  funnel চলে (`hi` → `hi there`, `m 21` → `f.25`, `usa` → `wanna be brave with me`);
  chitchat.gg network sandbox-এ ব্লকড — **final live test ইউজারের PC-তে বাকি।**
- **Browser mode:** আগের মতোই, একই ChatRuleBot।
- **Test:** matcher ✓, live 44/44, fuzz 4/4, flow 125/125, demo ✓ (sandbox-এ যাচাই)।
- **Known risk:** `chat/chat_db.py` ও `chat/database/loader.py`-তে hard-coded DB path
  আছে (`EVA_BOT_DB_ROOT` env দিয়ে override হয়)। `browser/browser_automation.py`
  বড় ও fragile — ছোঁয়ার আগে ভালো করে পড়ো।
- **Session data sensitivity:** zip-এ `account_sessions/` থাকলে তাতে login token
  থাকে — ডেলিভারি zip-এ এটা রাখা উচিত নয় (§6)।

---

## 9. Agent-কে শেষে যা লিখতে হবে

- **Result:** কী হলো (এক লাইনে)
- **Root cause:** CONFIRMED / LIKELY / UNKNOWN আলাদা করে
- **Changes:** ফাইল + function
- **Verification:** যেসব command সত্যি চালানো হয়েছে + pass/fail
- **Remaining risk:** কী যাচাই হয়নি (যেমন live network)

- **v19:** Picture sender সম্পূর্ণ সরানো হয়েছে — Dashboard-এর PICTURE SENDER group, Pictures page, Settings-এর picture config, browser/thread_manager-এর pic পরামিতি ও upload কোড। Chat engine (eva_flow / chat/*) অপরিবর্তিত; user-এর "send pic" কথার keyword detection engine-এ আছে, সেটা picture sender নয়।
