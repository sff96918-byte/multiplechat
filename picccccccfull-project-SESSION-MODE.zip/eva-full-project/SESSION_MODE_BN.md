# ⚡ SESSION MODE — token/session দিয়ে chat (browser ছাড়া)

নতুন যোগ হলো — **account session/acc token** দিয়ে সরাসরি chat।
Browser automation চালু করতে হয় না, বট WS (capture-backed protocol) দিয়ে chat করে।
**বাকি সব আগের মতোই** — flow funnel (data/input + data/output), snap, সব একই।

## চালানোর ৩ রাস্তা

### রাস্তা ১ — সবচেয়ে সহজ (double-click)
```
run_session_bot.bat
```
আপনার `account_sessions/`-এ যে session আগে থেকেই আছে সেটা auto নিয়ে চলবে।

### রাস্তা ২ — GUI থেকে
**SESSIONS পেজ** → উপরে নতুন box: **"⚡ SESSION MODE"** → ▶ চাপো।
Log-এ `[session]` দিয়ে সব output দেখা যাবে।

### রাস্তা ৩ — Command (নিয়ন্ত্রণ সহ)
```bash
python -m session_mode.runner --list          # কোন কোন session পাওয়া গেছে
python -m session_mode.runner --use 1         # ১ নম্বর session
python -m session_mode.runner --account 2ca428  # account folder নাম দিয়ে
python -m session_mode.runner --token eyJhbGci...   # raw acc token
python -m session_mode.runner --max-matches 3 # প্রথম টেস্টের জন্য
```

## Session ৩ উৎস থেকে খোঁজে (ক্রম)
1. `configs/session.json` — `{"cookies": {"token": "..."}, "user_agent": "..."}`
2. `account_sessions/*/storage_state.json` — browser mode save করা sessions (token cookie সহ)
3. `--token` — সরাসরি acc token paste

## জরুরি নোট
- Token মেয়াদ শেষ হলে (401): browser-এ chitchat.gg login করে আবার session বানাও —
  browser mode একবার চালালেই `account_sessions/` আপডেট হয়।
- Token **কখনো log/print হয় না** — শুধু শেষ ৬ অক্ষর দেখায়।
- Snap username: `snapchat_username.txt` (browser mode-এর মতোই) → বট `%username%`-এ rotate করে।
- প্রথম টেস্টে `--max-matches 2` দিয়ে চালানো ভালো।
