"""Capture-backed chitchat.gg WebSocket transport (session-token chat).

এই ফাইলগুলো real captured protocol থেকে বানানো — browser লাগে না।
শুধু session/account token দিলেই REST + Socket.IO-তে chat চলে।
"""
