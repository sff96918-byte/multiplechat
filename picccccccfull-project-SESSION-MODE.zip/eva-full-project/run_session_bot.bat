@echo off
title EVA - SESSION MODE (token chat, no browser)
cd /d "%~dp0"

echo.
echo ============================================================
echo    EVA SESSION MODE - account token diye chat (no browser)
echo ============================================================
echo.

where python >nul 2>&1
if errorlevel 1 (
    echo   X  Python NOT FOUND - python.org theke Python 3.10+ install koro
    pause
    exit /b 1
)

python -c "import aiohttp" >nul 2>&1
if errorlevel 1 (
    echo   [..] Installing aiohttp ^(one-time^)...
    pip install aiohttp
)

echo   [ok] session khuje neyaa hocche (account_sessions / session.json / --token)
echo.
python -u -m session_mode.runner %*

echo.
pause
