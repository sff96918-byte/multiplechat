"""Session-mode reply engine — wraps the project's own EvaFlowBot.

Browser automation-এর বদলে WS loop থেকে যে engine API দরকার:
  opener(partner) / reply(partner, incoming) / delay_for(incoming) /
  opener_delay() / forget(partner_id)

flow funnel হুবহু browser mode-এর মতোই (data/input + data/output)।
"""

from __future__ import annotations

import logging
import os
import random
import time
from pathlib import Path
from typing import Any, Dict, Optional

sys_path_note = None  # (runner sys.path সাজায়)
import eva_flow  # noqa: E402

log = logging.getLogger("session.engine")

# Human pacing (browser mode-এর মানের কাছাকাছি; config পরে যোগ করা যাবে)
DEFAULT_TIMING: Dict[str, Any] = {
    "reaction_pause_s": [0.5, 1.2],
    "typing_speed_cps": [6.0, 12.0],
    "read_reply_s": [1.0, 3.0],
    "micro_idle_chance": 0.25,
    "micro_idle_s": [0.5, 2.0],
    "new_chat_delay_s": [3.0, 6.0],
}


def write_snap_ids(data_dir: Path, snap_usernames) -> None:
    """snapchat_username.txt-এর নামগুলো data/snap_ids.txt-এ দেয় (eva_flow এটাই পড়ে)।"""
    names = [s.strip() for s in (snap_usernames or []) if s and s.strip()]
    try:
        data_dir.mkdir(parents=True, exist_ok=True)
        (data_dir / "snap_ids.txt").write_text("\n".join(names) + "\n", encoding="utf-8")
        if names:
            log.info("snap pool: %dta -> %s", len(names), data_dir / "snap_ids.txt")
    except Exception as exc:  # noqa: BLE001
        log.warning("snap_ids write skip: %s", exc)


def load_snap_usernames(root: Path):
    """snapchat_username.txt (root-এ, browser mode-ও এটাই ব্যবহার করে)।"""
    f = root / "snapchat_username.txt"
    if f.exists():
        return [l.strip() for l in f.read_text(encoding="utf-8").splitlines()
                if l.strip() and not l.strip().startswith("#")]
    return []


class SessionFlowEngine:
    """EvaFlowBot-কে WS loop-এর engine বানায় — funnel একই।"""

    name = "flow"

    def __init__(self, root: Optional[Path] = None,
                 snap_usernames=None,
                 timing: Optional[Dict[str, Any]] = None) -> None:
        root = Path(root) if root else Path.cwd()
        self.root = root
        write_snap_ids(root / "data", snap_usernames if snap_usernames is not None
                       else load_snap_usernames(root))
        self.bot = eva_flow.EvaFlowBot(root=str(root))
        self._states: Dict[str, Dict[str, Any]] = {}
        self.timing: Dict[str, Any] = dict(DEFAULT_TIMING)
        if timing:
            self.timing.update(timing)

    # ------------------------------------------------------------- WS loop API
    def _state_for(self, partner: dict) -> Dict[str, Any]:
        pid = (partner or {}).get("id") or "?"
        if pid not in self._states:
            self._states[pid] = self.bot.new_conversation()
        return self._states[pid]

    def opener(self, partner: dict) -> str:
        state = self._state_for(partner)
        reply = self.bot.reply("hi", state)  # greeting pool
        log.debug("opener via %s (%s)", self.bot.last_file, self.bot.last_reason)
        return reply

    def reply(self, partner: dict, incoming: str,
              history: Optional[list] = None) -> str:
        state = self._state_for(partner)
        reply = self.bot.reply(incoming or "hi", state)
        log.debug("flow %r -> %r | %s (%s)", (incoming or "")[:40],
                  (reply or "")[:60], self.bot.last_file, self.bot.last_reason)
        return reply

    def forget(self, partner_id: str) -> None:
        self._states.pop(partner_id, None)

    def delay_for(self, incoming: str) -> float:
        t = self.timing
        cps = random.uniform(*t["typing_speed_cps"])
        total = (random.uniform(*t["reaction_pause_s"])
                 + random.uniform(*t["read_reply_s"])
                 + min(len(incoming or "hi") / max(cps, 1.0), 12.0))
        if random.random() < float(t.get("micro_idle_chance", 0.25)):
            total += random.uniform(*t["micro_idle_s"])
        return round(total, 2)

    def opener_delay(self) -> float:
        return round(random.uniform(*self.timing.get("new_chat_delay_s", [3.0, 6.0])), 2)
