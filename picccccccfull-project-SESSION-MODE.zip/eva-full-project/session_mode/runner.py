"""SESSION MODE runner — account token/session দিয়ে browser ছাড়া chat।

চালানো:
  python -m session_mode.runner                     # session auto-detect + list দেখাবে
  python -m session_mode.runner --list              # কোন কোন session পাওয়া গেছে
  python -m session_mode.runner --use 1             # list-এর ১ নম্বর session দিয়ে চালাও
  python -m session_mode.runner --account 2ca428    # account folder নামের অংশ দিয়ে
  python -m session_mode.runner --token eyJhbGci...  # raw acc token দিয়ে
  python -m session_mode.runner --max-matches 3     # প্রথম টেস্টের জন্য
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
import time
from pathlib import Path
from typing import Callable, Optional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ws_transport.chitchat_api import ChitchatApi, SessionExpiredError
from ws_transport.chitchat_socket import ChitchatSocket
from ws_transport.protocol import DEFAULT_UA
from ws_transport.ws_chat_loop import LoopConfig, WsChatLoop

from session_mode.engine import SessionFlowEngine
from session_mode.session_store import (cookies_from_token, cookies_from_session_json,
                                        discover)

log = logging.getLogger("session.runner")

USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")


def pick_session(args: argparse.Namespace) -> tuple:
    """(--token/--account/--use/--auto) -> (cookies, ua, label)"""
    if args.token:
        cks, ua = cookies_from_token(args.token)
        return cks, ua or USER_AGENT, "raw --token"
    sessions = discover(ROOT)
    if not sessions:
        raise RuntimeError(
            "কোনো session পাওয়া যায়নি!\n"
            "  রাস্তা ১: browser mode-এ login করে account_sessions বানাও (already থাকলে auto পাবে)\n"
            "  রাস্তা ২: configs/session.json রাখো {\"cookies\": {\"token\": \"...\"}}\n"
            "  রাস্তা ৩: python -m session_mode.runner --token <acc token>")
    if args.account:
        for s in sessions:
            if args.account.lower() in s["source"].lower():
                return s["cookies"], s["ua"] or USER_AGENT, s["label"]
        raise RuntimeError(f"'{args.account}' মেলেনি। --list দিয়ে দেখো।")
    if args.use is not None:
        if not (1 <= args.use <= len(sessions)):
            raise RuntimeError(f"--use {args.use} সীমার বাইরে (1-{len(sessions)})।")
        s = sessions[args.use - 1]
        return s["cookies"], s["ua"] or USER_AGENT, s["label"]
    # auto: প্রথমটা
    s = sessions[0]
    return s["cookies"], s["ua"] or USER_AGENT, s["label"]


async def run_session(cookies: dict, ua: str, engine: SessionFlowEngine,
                      max_matches: int = 0, on_log: Callable[[str], None] = print,
                      loop_cfg: Optional[LoopConfig] = None) -> dict:
    api = ChitchatApi(cookies, user_agent=ua)
    me = await api.me()   # preflight — token মরা থাকলে এখানেই বাংলা error
    who = me.get("username", "?")
    on_log(f"[ok] token valid — logged in as {who} (id={me.get('id')})")

    socket = ChitchatSocket(cookies, user_agent=ua)
    cfg = loop_cfg or LoopConfig()
    loop = WsChatLoop(api, socket, engine, cfg)
    await loop.start()
    on_log("[ok] SESSION MODE LIVE — token দিয়ে chat চলছে (browser লাগে না)")

    t0 = time.monotonic()
    try:
        while loop._running:
            await asyncio.sleep(5)
            st = loop.stats.snapshot()
            on_log(f"[stat] state={loop.state.value} partner={loop.partner.display() if loop.partner else '-'} "
                   f"matches={st['matches']} sent={st['messages_sent']} "
                   f"recv={st['messages_received']} up={int(time.monotonic()-t0)}s")
            if max_matches and st["matches"] >= max_matches:
                on_log(f"[i] max-matches {max_matches} হয়েছে — থামানো হচ্ছে")
                await loop.stop("max-matches")
    except KeyboardInterrupt:
        await loop.stop("ctrl-c")
    finally:
        await api.close()
    stats = loop.stats.snapshot()
    on_log("[done] " + json.dumps(stats))
    return stats


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="EVA Session Mode — token দিয়ে chat (no browser)")
    ap.add_argument("--token", default="", help="raw account token (chitchat token cookie)")
    ap.add_argument("--account", default="", help="account_sessions folder নামের অংশ (যেমন 2ca428)")
    ap.add_argument("--use", type=int, default=None, help="--list এর নম্বর অনুযায়ী session বাছাই")
    ap.add_argument("--list", action="store_true", help="পাওয়া sessions দেখাও আর বেরিয়ে যাও")
    ap.add_argument("--max-matches", type=int, default=0, help="N match পরে auto-stop (0=আনলিমিটেড)")
    ap.add_argument("--debug", action="store_true", help="verbose log")
    args = ap.parse_args(argv)

    logging.basicConfig(level=logging.DEBUG if args.debug else logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
                        datefmt="%H:%M:%S")
    for noisy in ("aiohttp", "asyncio"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    sessions = discover(ROOT)
    if args.list:
        print(f"{len(sessions)}ta session পাওয়া গেছে:")
        for i, s in enumerate(sessions, 1):
            print(f"  {i}. {s['label']}  <- {s['source']}")
        return 0

    try:
        cookies, ua, label = pick_session(args)
    except RuntimeError as exc:
        print(f"[X] {exc}")
        return 1
    print(f"[i] session: {label}  (token: …{cookies.get('token', '')[-6:]})")

    engine = SessionFlowEngine(root=ROOT)
    try:
        asyncio.run(run_session(cookies, ua, engine, max_matches=args.max_matches))
    except SessionExpiredError:
        print("[X] SESSION মেয়াদ শেষ (401) — browser-এ chitchat.gg login করে নতুন session/token দাও")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
