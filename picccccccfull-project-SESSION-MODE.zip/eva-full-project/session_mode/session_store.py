"""Session/token বের করা — ৩ উৎস:

  1. configs/session.json           ({"cookies": {...}, "user_agent": "..."})
  2. account_sessions/*/storage_state.json  (browser mode-এর saved sessions)
  3. raw token string               (CLI --token, acc token)

কোনোভাবেই token log/print হয় না — শুধু label দেখানো হয়।
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("session.store")

DOMAIN_HINT = "chitchat"
REQUIRED = "token"


def _root() -> Path:
    from pathlib import Path as P
    return P(__file__).resolve().parents[1]


def cookies_from_storage_state(path: Path) -> Tuple[Dict[str, str], str]:
    """Playwright storage_state.json -> ({name: value}, user_agent)."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    picked: Dict[str, str] = {}
    for c in data.get("cookies") or []:
        if DOMAIN_HINT in (c.get("domain") or "").lstrip(".") and c.get("value"):
            picked[c["name"]] = c["value"]
    if REQUIRED not in picked:
        raise RuntimeError(f"{path}-এ chitchat 'token' cookie নেই "
                           f"(cookies: {sorted(picked.keys())})")
    return picked, ""


def cookies_from_session_json(path: Path) -> Tuple[Dict[str, str], str]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    cks = data.get("cookies") or {}
    if REQUIRED not in cks:
        raise RuntimeError(f"{path}-এ cookies.token নেই")
    return dict(cks), data.get("user_agent") or ""


def cookies_from_token(token: str) -> Tuple[Dict[str, str], str]:
    token = (token or "").strip()
    if not token:
        raise RuntimeError("token খালি")
    return {"token": token}, ""


def discover(root: Optional[Path] = None) -> List[dict]:
    """সব usable session-এর list: [{label, cookies, ua, source}]।"""
    root = Path(root) if root else _root()
    out: List[dict] = []
    sj = root / "configs" / "session.json"
    if sj.exists():
        try:
            cks, ua = cookies_from_session_json(sj)
            label = "session.json"
            user = "?"
            try:
                import base64
                parts = cks[REQUIRED].split(".")
                if len(parts) >= 2:
                    pad = parts[1] + "=" * (-len(parts[1]) % 4)
                    payload = json.loads(base64.urlsafe_b64decode(pad))
                    user = payload.get("username") or payload.get("id") or "?"
            except Exception:  # noqa: BLE001
                pass
            out.append({"label": f"{label} (user: {user})",
                        "cookies": cks, "ua": ua, "source": str(sj)})
        except Exception as exc:  # noqa: BLE001
            log.warning("session.json skip: %s", exc)
    adir = root / "account_sessions"
    if adir.is_dir():
        for d in sorted(adir.iterdir()):
            ss = d / "storage_state.json"
            if not ss.exists():
                continue
            try:
                cks, ua = cookies_from_storage_state(ss)
                meta = {}
                mp = d / "metadata.json"
                if mp.exists():
                    try:
                        meta = json.loads(mp.read_text(encoding="utf-8"))
                    except Exception:  # noqa: BLE001
                        pass
                email = meta.get("email") or d.name.replace("account_", "")
                out.append({"label": f"{d.name[:8]}… ({email})",
                            "cookies": cks, "ua": ua, "source": str(ss)})
            except Exception as exc:  # noqa: BLE001
                log.debug("account session skip %s: %s", d.name, exc)
    return out
